import React from 'react'

const Finance = () => {
  return (
    <div>Finance</div>
  )
}

export default Finance